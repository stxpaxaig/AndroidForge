package com.ghosttap.data

import kotlinx.serialization.Serializable

@Serializable
enum class TargetType {
    BLE,
    BLUETOOTH_CLASSIC,
    NFC,
    USB,
    NETWORK,
    SENSOR
}

@Serializable
data class Capability(
    val id: String,
    val title: String,
    val kind: ControlKind,
    val readable: Boolean = false,
    val writable: Boolean = false,
    val notifiable: Boolean = false,
    val metadata: Map<String, String> = emptyMap()
)

@Serializable
enum class ControlKind {
    BUTTON,
    SWITCH,
    SLIDER,
    INPUT,
    RAW
}

@Serializable
data class ScanTarget(
    val id: String,
    val name: String,
    val type: TargetType,
    val identity: Map<String, String> = emptyMap(),
    val capabilities: List<Capability> = emptyList(),
    val rssi: Int? = null,
    val connected: Boolean = false,
    val watchValues: Map<String, String> = emptyMap(),
    val requiresAuth: Boolean = false,
    val lastSeenMs: Long = System.currentTimeMillis()
)

@Serializable
data class BaselineSnapshot(
    val timestampMs: Long,
    val targets: Map<String, BaselineTarget>
)

@Serializable
data class BaselineTarget(
    val id: String,
    val name: String,
    val type: TargetType,
    val fingerprint: String,
    val rssi: Int?
)

@Serializable
data class BaselineDiff(
    val newTargets: List<String> = emptyList(),
    val missingTargets: List<String> = emptyList(),
    val changedTargets: List<String> = emptyList(),
    val signalChangedTargets: List<String> = emptyList()
)
