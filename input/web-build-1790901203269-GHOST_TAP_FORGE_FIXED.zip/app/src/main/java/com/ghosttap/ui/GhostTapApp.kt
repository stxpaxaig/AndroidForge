package com.ghosttap.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.ghosttap.GhostTapViewModel
import com.ghosttap.data.Capability
import com.ghosttap.data.ControlKind
import com.ghosttap.data.ScanTarget
import com.ghosttap.data.TargetType
import kotlinx.coroutines.launch

private val Bg = Color(0xFF050505)
private val Panel = Color(0xFF101010)
private val Accent = Color(0xFF44FF99)
private val Dim = Color(0xFF7AFFC4)

@Composable
fun GhostTapApp(viewModel: GhostTapViewModel, onNeedPermissions: () -> Unit) {
    val nav = rememberNavController()
    val tick = viewModel.uiTick
    val targets = remember(tick) { viewModel.allTargets }
    val logs = viewModel.logs

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            NavHost(navController = nav, startDestination = "home") {
                composable("home") {
                    HomeScreen(
                        targets = targets,
                        baselineText = formatBaselineDiff(viewModel),
                        isScanning = viewModel.isScanning(),
                        onScan = {
                            onNeedPermissions()
                            viewModel.startScan()
                        },
                        onStop = viewModel::stopScan,
                        onSaveBaseline = viewModel::saveBaseline,
                        onCompareBaseline = viewModel::compareWithBaseline,
                        onOpenTarget = { id ->
                            viewModel.selectTarget(id)
                            nav.navigate("target/$id")
                        },
                        onOpenLogs = { nav.navigate("logs") }
                    )
                }

                composable(
                    route = "target/{id}",
                    arguments = listOf(navArgument("id") { type = NavType.StringType })
                ) {
                    val selected = viewModel.selectedTarget()
                    if (selected != null) {
                        TargetScreen(
                            target = selected,
                            viewModel = viewModel,
                            onBack = { nav.popBackStack() }
                        )
                    } else {
                        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                            Text("Target missing", color = Accent)
                            Button(onClick = { nav.popBackStack() }) { Text("Back") }
                        }
                    }
                }

                composable("logs") {
                    val list = logs.value
                    LogsScreen(
                        lines = list.map { "${it.timestampMs} [${it.category}] (${it.targetId ?: "-"}) ${it.message}" },
                        onBack = { nav.popBackStack() },
                        onClear = viewModel::clearLogs,
                        onExport = viewModel::exportLogsToFile
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    targets: List<ScanTarget>,
    baselineText: String,
    isScanning: Boolean,
    onScan: () -> Unit,
    onStop: () -> Unit,
    onSaveBaseline: () -> Unit,
    onCompareBaseline: () -> Unit,
    onOpenTarget: (String) -> Unit,
    onOpenLogs: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
            .background(Bg),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("GHOST TAP", color = Accent, style = MaterialTheme.typography.headlineMedium, fontFamily = FontFamily.Monospace)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TerminalButton(if (isScanning) "SCANNING" else "SCAN", onScan)
            TerminalButton("STOP", onStop)
            TerminalButton("LOG", onOpenLogs)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TerminalButton("SAVE BASELINE", onSaveBaseline)
            TerminalButton("COMPARE", onCompareBaseline)
        }

        PanelBox(title = "BASELINE") {
            Text(baselineText, color = Dim, fontFamily = FontFamily.Monospace)
        }

        PanelBox(title = "TARGETS (${targets.size})") {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(targets) { target ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Panel, RoundedCornerShape(6.dp))
                            .clickable { onOpenTarget(target.id) }
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(target.name, color = Accent, fontFamily = FontFamily.Monospace)
                            Text("${target.type}  id=${target.id}", color = Dim, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text("RSSI: ${target.rssi ?: "n/a"}", color = Dim, fontFamily = FontFamily.Monospace)
                            Text(if (target.connected) "CONNECTED" else "DISCONNECTED", color = if (target.connected) Accent else Color.Gray, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TargetScreen(target: ScanTarget, viewModel: GhostTapViewModel, onBack: () -> Unit) {
    var rawInput by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("") }
    var nfcText by remember { mutableStateOf("") }
    var networkPath by remember { mutableStateOf("/") }
    var networkBody by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TerminalButton("BACK", onBack)
            TerminalButton("REFRESH WATCH") { viewModel.refreshUsbAndSensorsWatch() }
            if (target.type == TargetType.BLE && !target.connected) {
                TerminalButton("CONNECT") { viewModel.connectBle(target.id) }
            }
            if (target.type == TargetType.BLE && target.connected) {
                TerminalButton("DISCONNECT") { viewModel.disconnectBle(target.id) }
            }
        }

        PanelBox("IDENTITY") {
            Text(target.name, color = Accent, fontFamily = FontFamily.Monospace)
            target.identity.forEach { (k, v) ->
                Text("$k: $v", color = Dim, fontFamily = FontFamily.Monospace)
            }
            if (target.requiresAuth) {
                Text("AUTH REQUIRED", color = Color.Red, fontFamily = FontFamily.Monospace)
            }
        }

        PanelBox("CAPABILITIES") {
            target.capabilities.forEach { cap ->
                Text("${cap.title} [R=${cap.readable} W=${cap.writable} N=${cap.notifiable}]", color = Dim, fontFamily = FontFamily.Monospace)
            }
        }

        PanelBox("CONTROL") {
            when (target.type) {
                TargetType.NFC -> {
                    OutlinedTextField(
                        value = nfcText,
                        onValueChange = { nfcText = it },
                        label = { Text("NDEF text") }
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TerminalButton("WRITE NFC") {
                            output = if (viewModel.writeNdefText(nfcText)) "NDEF WRITE OK" else "NDEF WRITE FAILED"
                        }
                    }
                }

                TargetType.BLE -> {
                    BleCapabilityControls(
                        capabilities = target.capabilities,
                        onRead = { service, char -> viewModel.bleRead(target.id, service, char) },
                        onNotify = { service, char, enable -> viewModel.bleSetNotify(target.id, service, char, enable) },
                        onWrite = { service, char, value -> viewModel.bleWrite(target.id, service, char, value) }
                    )
                }

                else -> {
                    Text("Auto controls exposed in RAW section for this protocol", color = Dim, fontFamily = FontFamily.Monospace)
                }
            }
        }

        PanelBox("WATCH") {
            Text("RSSI: ${target.rssi ?: "n/a"}", color = Dim, fontFamily = FontFamily.Monospace)
            Text("CONNECTED: ${target.connected}", color = Dim, fontFamily = FontFamily.Monospace)
            target.watchValues.forEach { (k, v) ->
                Text("$k => $v", color = Dim, fontFamily = FontFamily.Monospace)
            }
        }

        PanelBox("RAW") {
            when (target.type) {
                TargetType.USB -> {
                    OutlinedTextField(
                        value = rawInput,
                        onValueChange = { rawInput = it },
                        label = { Text("USB HEX payload") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    TerminalButton("USB TRANSFER") {
                        output = viewModel.usbRawTransfer(target.id, rawInput)
                    }
                }

                TargetType.NETWORK -> {
                    OutlinedTextField(
                        value = networkPath,
                        onValueChange = { networkPath = it },
                        label = { Text("Path") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = networkBody,
                        onValueChange = { networkBody = it },
                        label = { Text("Body") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TerminalButton("GET") {
                            scope.launch { output = viewModel.networkRawRequest(target.id, "GET", networkPath, "") }
                        }
                        TerminalButton("POST") {
                            scope.launch { output = viewModel.networkRawRequest(target.id, "POST", networkPath, networkBody) }
                        }
                    }
                }

                else -> {
                    OutlinedTextField(
                        value = rawInput,
                        onValueChange = { rawInput = it },
                        label = { Text("RAW input") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Raw mode depends on protocol access limits", color = Dim, fontFamily = FontFamily.Monospace)
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(output, color = Accent, fontFamily = FontFamily.Monospace)
        }

        PanelBox("LOG") {
            Text("Open LOG screen from main for full history", color = Dim, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
private fun BleCapabilityControls(
    capabilities: List<Capability>,
    onRead: (String, String) -> Unit,
    onNotify: (String, String, Boolean) -> Unit,
    onWrite: (String, String, String) -> Unit
) {
    var payload by remember { mutableStateOf("") }
    var notifyEnabled by remember { mutableStateOf(false) }

    val bleCaps = capabilities.filter { it.id.startsWith("ble:") && it.metadata.containsKey("service") }
    if (bleCaps.isEmpty()) {
        Text("No discovered BLE characteristics yet", color = Dim, fontFamily = FontFamily.Monospace)
        return
    }

    OutlinedTextField(
        value = payload,
        onValueChange = { payload = it },
        label = { Text("HEX payload") },
        modifier = Modifier.fillMaxWidth()
    )

    bleCaps.forEach { cap ->
        val service = cap.metadata["service"] ?: return@forEach
        val char = cap.metadata["char"] ?: return@forEach

        Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Text(cap.title, color = Dim, fontFamily = FontFamily.Monospace)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (cap.readable) TerminalButton("READ") { onRead(service, char) }
                if (cap.writable) TerminalButton("WRITE") { onWrite(service, char, payload) }
                if (cap.notifiable) {
                    TerminalButton(if (notifyEnabled) "NOTIFY OFF" else "NOTIFY ON") {
                        notifyEnabled = !notifyEnabled
                        onNotify(service, char, notifyEnabled)
                    }
                }
            }
        }
    }
}

@Composable
private fun LogsScreen(
    lines: List<String>,
    onBack: () -> Unit,
    onClear: () -> Unit,
    onExport: () -> java.io.File?
) {
    var exportResult by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TerminalButton("BACK", onBack)
            TerminalButton("CLEAR", onClear)
            TerminalButton("EXPORT") {
                val file = onExport()
                exportResult = file?.absolutePath ?: "Export failed"
            }
        }
        if (exportResult.isNotBlank()) {
            Text(exportResult, color = Accent, fontFamily = FontFamily.Monospace)
        }
        PanelBox("LOG") {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(lines) { line ->
                    Text(line, color = Dim, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
private fun TerminalButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF161616),
            contentColor = Accent
        )
    ) {
        Text(text, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun PanelBox(title: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Panel, RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            Text(title, color = Accent, fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.width(6.dp))
            Text("------------------------------------------------", color = Color(0xFF2A2A2A), fontFamily = FontFamily.Monospace)
        }
        Spacer(modifier = Modifier.height(6.dp))
        content()
    }
}

private fun formatBaselineDiff(viewModel: GhostTapViewModel): String {
    val diff = viewModel.baselineDiff
    return buildString {
        appendLine("NEW: ${diff.newTargets.size}")
        appendLine("MISSING: ${diff.missingTargets.size}")
        appendLine("CHANGED: ${diff.changedTargets.size}")
        appendLine("SIGNAL CHANGE: ${diff.signalChangedTargets.size}")
    }
}
