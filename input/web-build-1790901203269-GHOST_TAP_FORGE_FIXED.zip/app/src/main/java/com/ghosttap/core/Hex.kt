package com.ghosttap.core

fun ByteArray.toHexString(): String = joinToString(" ") { "%02X".format(it) }

fun String.hexToBytes(): ByteArray {
    val cleaned = replace(" ", "").replace("\n", "")
    require(cleaned.length % 2 == 0) { "Hex input length must be even" }
    return cleaned.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
}
