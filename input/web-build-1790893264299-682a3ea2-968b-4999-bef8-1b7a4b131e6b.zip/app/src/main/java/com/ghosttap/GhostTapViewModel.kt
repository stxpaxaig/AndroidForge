package com.ghosttap

import android.Manifest
import android.app.Application
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.nfc.Ndef
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.NdefFormatable
import android.os.Build
import android.os.ParcelUuid
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.ActivityCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ghosttap.core.hexToBytes
import com.ghosttap.core.toHexString
import com.ghosttap.data.BaselineDiff
import com.ghosttap.data.BaselineSnapshot
import com.ghosttap.data.BaselineStore
import com.ghosttap.data.BaselineTarget
import com.ghosttap.data.Capability
import com.ghosttap.data.ControlKind
import com.ghosttap.data.GhostTapDatabase
import com.ghosttap.data.LogEntry
import com.ghosttap.data.ScanTarget
import com.ghosttap.data.TargetType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs

class GhostTapViewModel(application: Application) : AndroidViewModel(application) {
    private val appContext = getApplication<Application>()
    private val db = GhostTapDatabase.get(appContext)
    private val baselineStore = BaselineStore(appContext)

    val logs: StateFlow<List<LogEntry>> = db.logDao().observeAll()
        .map { it.take(500) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val targets = ConcurrentHashMap<String, ScanTarget>()
    private val gattMap = ConcurrentHashMap<String, BluetoothGatt>()
    private val bleServices = ConcurrentHashMap<String, List<BluetoothGattService>>()

    @Volatile
    private var scanning = false

    var uiTick by mutableIntStateOf(0)
        private set

    @Volatile
    var selectedTargetId: String? = null

    @Volatile
    var baselineDiff: BaselineDiff = BaselineDiff()
        private set

    @Volatile
    var lastNfcTag: Tag? = null
        private set

    @Volatile
    var audioSpectrumSummary: String = "N/A"
        private set

    private var audioJob: Job? = null

    val allTargets: List<ScanTarget>
        get() = targets.values.sortedByDescending { it.lastSeenMs }

    private val bluetoothManager = appContext.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager.adapter
    private val bleScanner: BluetoothLeScanner?
        get() = bluetoothAdapter?.bluetoothLeScanner

    private val nsdManager = appContext.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val usbManager = appContext.getSystemService(Context.USB_SERVICE) as UsbManager
    private val sensorManager = appContext.getSystemService(Context.SENSOR_SERVICE) as SensorManager

    private val bleScanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val address = result.device.address ?: return
            val cap = mutableListOf<Capability>()
            cap += Capability("ble_connect", "BLE Connect", ControlKind.BUTTON, readable = true, writable = true)

            val serviceIds = result.scanRecord?.serviceUuids?.map(ParcelUuid::toString).orEmpty()
            val identity = mutableMapOf(
                "address" to address,
                "protocol" to "BLE",
                "bondState" to result.device.bondState.toString(),
                "txPower" to (result.txPower.takeIf { it != Int.MIN_VALUE }?.toString() ?: "unknown")
            )
            if (serviceIds.isNotEmpty()) {
                identity["advertisedServices"] = serviceIds.joinToString(",")
            }

            upsertTarget(
                ScanTarget(
                    id = "ble:$address",
                    name = result.device.name ?: "BLE-$address",
                    type = TargetType.BLE,
                    identity = identity,
                    capabilities = cap,
                    rssi = result.rssi,
                    connected = gattMap.containsKey("ble:$address"),
                    lastSeenMs = System.currentTimeMillis()
                )
            )
        }
    }

    private val btReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    } ?: return
                    val rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE).toInt()
                    val address = device.address ?: return
                    upsertTarget(
                        ScanTarget(
                            id = "bt:$address",
                            name = device.name ?: "BT-$address",
                            type = TargetType.BLUETOOTH_CLASSIC,
                            identity = mapOf(
                                "address" to address,
                                "protocol" to "Bluetooth Classic",
                                "bondState" to device.bondState.toString(),
                                "class" to (device.bluetoothClass?.majorDeviceClass?.toString() ?: "unknown")
                            ),
                            capabilities = listOf(
                                Capability("bt_pair", "Pair / Auth", ControlKind.BUTTON, readable = true),
                                Capability("bt_auth", "Auth Required", ControlKind.BUTTON)
                            ),
                            rssi = if (rssi == Short.MIN_VALUE.toInt()) null else rssi,
                            requiresAuth = device.bondState != BluetoothDevice.BOND_BONDED,
                            lastSeenMs = System.currentTimeMillis()
                        )
                    )
                }
            }
        }
    }

    private val sensorListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent?) {
            event ?: return
            val typeName = when (event.sensor.type) {
                Sensor.TYPE_MAGNETIC_FIELD -> "Magnetometer"
                Sensor.TYPE_ACCELEROMETER -> "Accelerometer"
                Sensor.TYPE_GYROSCOPE -> "Gyroscope"
                else -> return
            }
            val values = event.values.joinToString(prefix = "[", postfix = "]") { "%.3f".format(it) }
            upsertTarget(
                ScanTarget(
                    id = "sensor:${event.sensor.type}",
                    name = typeName,
                    type = TargetType.SENSOR,
                    identity = mapOf(
                        "vendor" to event.sensor.vendor,
                        "version" to event.sensor.version.toString(),
                        "power_mA" to event.sensor.power.toString()
                    ),
                    capabilities = listOf(Capability("watch", "Watch", ControlKind.RAW, readable = true)),
                    watchValues = mapOf("values" to values, "audio" to audioSpectrumSummary),
                    lastSeenMs = System.currentTimeMillis()
                )
            )
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
    }

    fun startScan() {
        if (scanning) return
        scanning = true
        registerBtReceiver()
        startClassicDiscovery()
        startBleScan()
        inspectUsbNow()
        startNsdDiscovery()
        startSensors()
        startAudioMonitor()
        log("SYSTEM", null, "Scan started")
    }

    fun stopScan() {
        scanning = false
        runCatching { bleScanner?.stopScan(bleScanCallback) }
        runCatching { bluetoothAdapter?.cancelDiscovery() }
        runCatching { appContext.unregisterReceiver(btReceiver) }
        stopNsdDiscovery()
        stopSensors()
        stopAudioMonitor()
        log("SYSTEM", null, "Scan stopped")
    }

    fun isScanning(): Boolean = scanning

    private fun registerBtReceiver() {
        val filter = IntentFilter(BluetoothDevice.ACTION_FOUND)
        runCatching { appContext.registerReceiver(btReceiver, filter) }
    }

    private fun startClassicDiscovery() {
        val adapter = bluetoothAdapter ?: return
        val hasBtPerm = hasPermission(Manifest.permission.BLUETOOTH_SCAN) || Build.VERSION.SDK_INT < Build.VERSION_CODES.S
        if (!hasBtPerm) return
        runCatching {
            if (adapter.isDiscovering) adapter.cancelDiscovery()
            adapter.startDiscovery()
        }
    }

    private fun startBleScan() {
        val scanner = bleScanner ?: return
        val hasPerm = hasPermission(Manifest.permission.BLUETOOTH_SCAN) || Build.VERSION.SDK_INT < Build.VERSION_CODES.S
        if (!hasPerm) return
        runCatching { scanner.startScan(bleScanCallback) }
    }

    private val nsdListeners = mutableListOf<NsdManager.DiscoveryListener>()

    private fun startNsdDiscovery() {
        val serviceTypes = listOf("_http._tcp.", "_https._tcp.", "_mqtt._tcp.")
        serviceTypes.forEach { type ->
            val listener = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(regType: String) = Unit
                override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) = Unit
                override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) = Unit
                override fun onDiscoveryStopped(serviceType: String) = Unit
                override fun onServiceLost(serviceInfo: NsdServiceInfo) = Unit

                override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                    nsdManager.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) = Unit

                        override fun onServiceResolved(resolved: NsdServiceInfo) {
                            val host = resolved.host?.hostAddress ?: "unknown"
                            val port = resolved.port
                            val id = "net:${resolved.serviceName}:$host:$port"
                            upsertTarget(
                                ScanTarget(
                                    id = id,
                                    name = resolved.serviceName,
                                    type = TargetType.NETWORK,
                                    identity = mapOf(
                                        "serviceType" to resolved.serviceType,
                                        "host" to host,
                                        "port" to port.toString()
                                    ),
                                    capabilities = listOf(
                                        Capability("net_get", "HTTP GET", ControlKind.BUTTON, readable = true),
                                        Capability("net_raw", "RAW HTTP", ControlKind.RAW, readable = true, writable = true)
                                    ),
                                    lastSeenMs = System.currentTimeMillis()
                                )
                            )
                        }
                    })
                }
            }
            runCatching {
                nsdManager.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, listener)
                nsdListeners += listener
            }
        }
    }

    private fun stopNsdDiscovery() {
        nsdListeners.forEach { listener ->
            runCatching { nsdManager.stopServiceDiscovery(listener) }
        }
        nsdListeners.clear()
    }

    private fun startSensors() {
        listOf(
            Sensor.TYPE_MAGNETIC_FIELD,
            Sensor.TYPE_ACCELEROMETER,
            Sensor.TYPE_GYROSCOPE
        ).mapNotNull(sensorManager::getDefaultSensor)
            .forEach { sensor ->
                sensorManager.registerListener(sensorListener, sensor, SensorManager.SENSOR_DELAY_NORMAL)
            }
    }

    private fun stopSensors() {
        sensorManager.unregisterListener(sensorListener)
    }

    private fun startAudioMonitor() {
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) return
        if (audioJob != null) return
        audioJob = viewModelScope.launch(Dispatchers.Default) {
            val sampleRate = 8000
            val minSize = AudioRecord.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            if (minSize <= 0) return@launch
            val recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minSize * 2
            )
            val buffer = ShortArray(minSize)
            runCatching { recorder.startRecording() }
            while (isActive && scanning) {
                val read = recorder.read(buffer, 0, buffer.size)
                if (read > 0) {
                    var zeroCross = 0
                    var sumAbs = 0.0
                    for (i in 1 until read) {
                        val prev = buffer[i - 1]
                        val cur = buffer[i]
                        if ((prev >= 0 && cur < 0) || (prev < 0 && cur >= 0)) zeroCross++
                        sumAbs += abs(cur.toInt())
                    }
                    val avg = (sumAbs / read) / 32767.0
                    val freq = zeroCross * (sampleRate / (2.0 * read))
                    audioSpectrumSummary = "amp=${"%.3f".format(avg)} domHz=${"%.1f".format(freq)}"
                }
            }
            runCatching { recorder.stop() }
            recorder.release()
        }
    }

    private fun stopAudioMonitor() {
        audioJob?.cancel()
        audioJob = null
    }

    private fun inspectUsbNow() {
        usbManager.deviceList.values.forEach { device ->
            upsertTarget(
                ScanTarget(
                    id = "usb:${device.deviceId}",
                    name = device.productName ?: "USB-${device.deviceId}",
                    type = TargetType.USB,
                    identity = mapOf(
                        "vendorId" to device.vendorId.toString(),
                        "productId" to device.productId.toString(),
                        "class" to device.deviceClass.toString(),
                        "subclass" to device.deviceSubclass.toString(),
                        "interfaces" to device.interfaceCount.toString(),
                        "serial" to (device.serialNumber ?: "n/a")
                    ),
                    capabilities = buildUsbCapabilities(device),
                    lastSeenMs = System.currentTimeMillis()
                )
            )
        }
    }

    private fun buildUsbCapabilities(device: UsbDevice): List<Capability> {
        val caps = mutableListOf<Capability>()
        for (i in 0 until device.interfaceCount) {
            val intf = device.getInterface(i)
            for (e in 0 until intf.endpointCount) {
                val endpoint = intf.getEndpoint(e)
                val direction = if (endpoint.direction == UsbConstants.USB_DIR_IN) "IN" else "OUT"
                caps += Capability(
                    id = "usb_${i}_${e}",
                    title = "IF${i} EP${e} $direction",
                    kind = ControlKind.RAW,
                    readable = endpoint.direction == UsbConstants.USB_DIR_IN,
                    writable = endpoint.direction == UsbConstants.USB_DIR_OUT,
                    metadata = mapOf(
                        "type" to endpoint.type.toString(),
                        "maxPacketSize" to endpoint.maxPacketSize.toString()
                    )
                )
            }
        }
        if (caps.isEmpty()) {
            caps += Capability("usb_info", "Descriptor only", ControlKind.BUTTON, readable = true)
        }
        return caps
    }

    fun handleNfcIntent(intent: Intent?) {
        intent ?: return
        val action = intent.action ?: return
        if (action != NfcAdapter.ACTION_TAG_DISCOVERED && action != NfcAdapter.ACTION_NDEF_DISCOVERED) return
        val tag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(NfcAdapter.EXTRA_TAG, Tag::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)
        } ?: return

        lastNfcTag = tag
        val techs = tag.techList.joinToString(",")
        val ndef = Ndef.get(tag)
        val writable = runCatching { ndef?.isWritable == true }.getOrDefault(false)
        val ndefText = readNdefText(tag)

        upsertTarget(
            ScanTarget(
                id = "nfc:${tag.id.toHexString()}",
                name = "NFC Tag ${tag.id.toHexString()}",
                type = TargetType.NFC,
                identity = mapOf(
                    "tagId" to tag.id.toHexString(),
                    "tech" to techs,
                    "ndefType" to (ndef?.type ?: "none"),
                    "maxSize" to (ndef?.maxSize?.toString() ?: "unknown"),
                    "writable" to writable.toString(),
                    "ndefText" to (ndefText ?: "none")
                ),
                capabilities = listOf(
                    Capability("nfc_read", "Read NDEF", ControlKind.BUTTON, readable = true),
                    Capability("nfc_write", "Write NDEF", ControlKind.INPUT, writable = writable)
                ),
                lastSeenMs = System.currentTimeMillis()
            )
        )
        log("NFC", "nfc:${tag.id.toHexString()}", "NFC tag detected")
    }

    private fun readNdefText(tag: Tag): String? {
        val ndef = Ndef.get(tag) ?: return null
        return runCatching {
            ndef.connect()
            val message = ndef.ndefMessage ?: return@runCatching null
            val payload = message.records.firstOrNull()?.payload ?: return@runCatching null
            String(payload, StandardCharsets.UTF_8)
        }.getOrNull().also {
            runCatching { ndef.close() }
        }
    }

    fun writeNdefText(text: String): Boolean {
        val tag = lastNfcTag ?: return false
        val ndef = Ndef.get(tag)
        if (ndef != null) {
            return runCatching {
                ndef.connect()
                if (!ndef.isWritable) {
                    log("NFC", null, "AUTH REQUIRED / tag not writable")
                    return@runCatching false
                }
                val record = NdefRecord.createTextRecord("en", text)
                val msg = NdefMessage(arrayOf(record))
                ndef.writeNdefMessage(msg)
                log("NFC", null, "NDEF write success")
                true
            }.getOrDefault(false).also { runCatching { ndef.close() } }
        }

        val formatable = NdefFormatable.get(tag)
        return if (formatable != null) {
            runCatching {
                formatable.connect()
                val record = NdefRecord.createTextRecord("en", text)
                val msg = NdefMessage(arrayOf(record))
                formatable.format(msg)
                log("NFC", null, "NDEF format+write success")
                true
            }.getOrDefault(false).also { runCatching { formatable.close() } }
        } else {
            false
        }
    }

    fun connectBle(targetId: String) {
        val target = targets[targetId] ?: return
        val address = target.identity["address"] ?: return
        if (!hasPermission(Manifest.permission.BLUETOOTH_CONNECT) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            log("BLE", targetId, "AUTH REQUIRED: BLUETOOTH_CONNECT permission")
            return
        }
        val device = bluetoothAdapter?.getRemoteDevice(address) ?: return
        val gatt = device.connectGatt(appContext, false, object : BluetoothGattCallback() {
            override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
                val connected = newState == BluetoothGatt.STATE_CONNECTED
                if (connected) {
                    gatt.discoverServices()
                }
                updateConnectionState(targetId, connected)
                log("BLE", targetId, "Connection state=$newState status=$status")
            }

            override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
                bleServices[targetId] = gatt.services
                val caps = mutableListOf<Capability>()
                caps += Capability("ble_disconnect", "Disconnect", ControlKind.BUTTON)
                gatt.services.forEach { service ->
                    service.characteristics.forEach { c ->
                        val props = c.properties
                        caps += Capability(
                            id = "ble:${service.uuid}:${c.uuid}",
                            title = "${service.uuid} / ${c.uuid}",
                            kind = ControlKind.RAW,
                            readable = props and BluetoothGattCharacteristic.PROPERTY_READ != 0,
                            writable = (props and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) ||
                                (props and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0),
                            notifiable = props and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0,
                            metadata = mapOf("service" to service.uuid.toString(), "char" to c.uuid.toString())
                        )
                    }
                }
                val old = targets[targetId] ?: return
                upsertTarget(old.copy(capabilities = caps, connected = true, lastSeenMs = System.currentTimeMillis()))
                log("BLE", targetId, "Services discovered: ${gatt.services.size}")
            }

            override fun onCharacteristicRead(
                gatt: BluetoothGatt,
                characteristic: BluetoothGattCharacteristic,
                value: ByteArray,
                status: Int
            ) {
                val key = characteristic.uuid.toString()
                val old = targets[targetId] ?: return
                val updatedWatch = old.watchValues + (key to value.toHexString())
                upsertTarget(old.copy(watchValues = updatedWatch, lastSeenMs = System.currentTimeMillis()))
                log("BLE", targetId, "READ ${characteristic.uuid} = ${value.toHexString()}")
            }

            override fun onCharacteristicChanged(
                gatt: BluetoothGatt,
                characteristic: BluetoothGattCharacteristic,
                value: ByteArray
            ) {
                val key = characteristic.uuid.toString()
                val old = targets[targetId] ?: return
                val updatedWatch = old.watchValues + (key to value.toHexString())
                upsertTarget(old.copy(watchValues = updatedWatch, lastSeenMs = System.currentTimeMillis()))
                log("BLE", targetId, "NOTIFY ${characteristic.uuid} = ${value.toHexString()}")
            }
        })
        gattMap[targetId] = gatt
    }

    private fun updateConnectionState(targetId: String, connected: Boolean) {
        val old = targets[targetId] ?: return
        upsertTarget(old.copy(connected = connected, lastSeenMs = System.currentTimeMillis()))
    }

    fun disconnectBle(targetId: String) {
        gattMap.remove(targetId)?.let { gatt ->
            runCatching { gatt.disconnect() }
            runCatching { gatt.close() }
        }
        updateConnectionState(targetId, false)
        log("BLE", targetId, "Disconnected")
    }

    fun bleRead(targetId: String, serviceUuid: String, charUuid: String) {
        val gatt = gattMap[targetId] ?: return
        val service = runCatching { gatt.getService(UUID.fromString(serviceUuid)) }.getOrNull() ?: return
        val characteristic = runCatching { service.getCharacteristic(UUID.fromString(charUuid)) }.getOrNull() ?: return
        runCatching { gatt.readCharacteristic(characteristic) }
    }

    fun bleWrite(targetId: String, serviceUuid: String, charUuid: String, hexPayload: String) {
        val gatt = gattMap[targetId] ?: return
        val service = runCatching { gatt.getService(UUID.fromString(serviceUuid)) }.getOrNull() ?: return
        val characteristic = runCatching { service.getCharacteristic(UUID.fromString(charUuid)) }.getOrNull() ?: return
        val payload = runCatching { hexPayload.hexToBytes() }.getOrElse {
            log("BLE", targetId, "Invalid hex payload")
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            gatt.writeCharacteristic(characteristic, payload, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT)
        } else {
            @Suppress("DEPRECATION")
            characteristic.value = payload
            @Suppress("DEPRECATION")
            gatt.writeCharacteristic(characteristic)
        }
        log("BLE", targetId, "WRITE ${characteristic.uuid} <= ${payload.toHexString()}")
    }

    fun bleSetNotify(targetId: String, serviceUuid: String, charUuid: String, enable: Boolean) {
        val gatt = gattMap[targetId] ?: return
        val service = runCatching { gatt.getService(UUID.fromString(serviceUuid)) }.getOrNull() ?: return
        val characteristic = runCatching { service.getCharacteristic(UUID.fromString(charUuid)) }.getOrNull() ?: return
        gatt.setCharacteristicNotification(characteristic, enable)
        characteristic.descriptors.forEach { descriptor ->
            if (descriptor.uuid == UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")) {
                val value = if (enable) BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE else BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    gatt.writeDescriptor(descriptor, value)
                } else {
                    @Suppress("DEPRECATION")
                    descriptor.value = value
                    @Suppress("DEPRECATION")
                    gatt.writeDescriptor(descriptor)
                }
            }
        }
        log("BLE", targetId, "NOTIFY ${if (enable) "ENABLED" else "DISABLED"}")
    }

    fun networkRawRequest(targetId: String, method: String, path: String, body: String): String {
        val target = targets[targetId] ?: return "Target not found"
        val host = target.identity["host"] ?: return "Host missing"
        val port = target.identity["port"] ?: return "Port missing"
        val url = "http://$host:$port${if (path.startsWith("/")) path else "/$path"}"
        return runCatching {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = method.uppercase()
                connectTimeout = 2500
                readTimeout = 2500
                doInput = true
                if (body.isNotBlank()) {
                    doOutput = true
                    setRequestProperty("Content-Type", "text/plain")
                    outputStream.use { it.write(body.toByteArray()) }
                }
            }
            val response = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            log("NETWORK", targetId, "${method.uppercase()} $url -> OK")
            response
        }.getOrElse {
            log("NETWORK", targetId, "${method.uppercase()} $url -> ${it.message}")
            "ERROR: ${it.message}"
        }
    }

    fun usbRawTransfer(targetId: String, payloadHex: String): String {
        val id = targetId.substringAfter("usb:").toIntOrNull() ?: return "Invalid USB target"
        val device = usbManager.deviceList.values.firstOrNull { it.deviceId == id } ?: return "USB device missing"
        if (!usbManager.hasPermission(device)) {
            log("USB", targetId, "AUTH REQUIRED: USB permission")
            return "AUTH REQUIRED"
        }
        val payload = runCatching { payloadHex.hexToBytes() }.getOrElse {
            return "Invalid hex input"
        }
        val connection = usbManager.openDevice(device) ?: return "Cannot open USB device"
        return connection.useWithResult(device) { conn, intf, outEndpoint, inEndpoint ->
            val outResult = if (outEndpoint != null) conn.bulkTransfer(outEndpoint, payload, payload.size, 1000) else -1
            val readBuf = ByteArray(64)
            val inResult = if (inEndpoint != null) conn.bulkTransfer(inEndpoint, readBuf, readBuf.size, 1000) else -1
            val inData = if (inResult > 0) readBuf.copyOf(inResult).toHexString() else ""
            log("USB", targetId, "OUT=$outResult IN=$inResult")
            "OUT=$outResult IN=$inResult DATA=$inData"
        }
    }

    private inline fun <T> UsbDeviceConnection.useWithResult(
        device: UsbDevice,
        block: (UsbDeviceConnection, UsbInterface, UsbEndpoint?, UsbEndpoint?) -> T
    ): T {
        var chosenInterface: UsbInterface? = null
        for (i in 0 until device.interfaceCount) {
            val intf = device.getInterface(i)
            if (claimInterface(intf, true)) {
                chosenInterface = intf
                break
            }
        }
        val intf = chosenInterface ?: throw IllegalStateException("No claimable USB interface")
        var inEp: UsbEndpoint? = null
        var outEp: UsbEndpoint? = null
        for (e in 0 until intf.endpointCount) {
            val ep = intf.getEndpoint(e)
            if (ep.direction == UsbConstants.USB_DIR_IN && inEp == null) inEp = ep
            if (ep.direction == UsbConstants.USB_DIR_OUT && outEp == null) outEp = ep
        }
        return try {
            block(this, intf, outEp, inEp)
        } finally {
            releaseInterface(intf)
            close()
        }
    }

    fun saveBaseline() {
        val snapshot = BaselineSnapshot(
            timestampMs = System.currentTimeMillis(),
            targets = allTargets.associate { target ->
                target.id to BaselineTarget(
                    id = target.id,
                    name = target.name,
                    type = target.type,
                    fingerprint = target.identity.entries.sortedBy { it.key }.joinToString("|") { "${it.key}=${it.value}" },
                    rssi = target.rssi
                )
            }
        )
        baselineStore.save(snapshot)
        log("BASELINE", null, "Baseline saved (${snapshot.targets.size} targets)")
    }

    fun compareWithBaseline() {
        val baseline = baselineStore.load() ?: run {
            baselineDiff = BaselineDiff()
            log("BASELINE", null, "No baseline saved")
            return
        }
        val current = allTargets.associateBy { it.id }

        val newTargets = current.keys.filterNot { baseline.targets.containsKey(it) }
        val missingTargets = baseline.targets.keys.filterNot { current.containsKey(it) }

        val changed = mutableListOf<String>()
        val signalChanged = mutableListOf<String>()

        current.forEach { (id, now) ->
            val old = baseline.targets[id] ?: return@forEach
            val nowFingerprint = now.identity.entries.sortedBy { it.key }.joinToString("|") { "${it.key}=${it.value}" }
            if (old.fingerprint != nowFingerprint) changed += id

            val oldRssi = old.rssi
            val nowRssi = now.rssi
            if (oldRssi != null && nowRssi != null && abs(oldRssi - nowRssi) >= 6) {
                signalChanged += id
            }
        }

        baselineDiff = BaselineDiff(
            newTargets = newTargets,
            missingTargets = missingTargets,
            changedTargets = changed,
            signalChangedTargets = signalChanged
        )
        uiTick++
        log("BASELINE", null, "Diff: new=${newTargets.size} missing=${missingTargets.size} changed=${changed.size} signal=${signalChanged.size}")
    }

    fun selectTarget(id: String?) {
        selectedTargetId = id
    }

    fun selectedTarget(): ScanTarget? = selectedTargetId?.let { targets[it] }

    fun refreshUsbAndSensorsWatch() {
        inspectUsbNow()
        val sensorTargets = allTargets.filter { it.type == TargetType.SENSOR }
        sensorTargets.forEach { target ->
            upsertTarget(target.copy(watchValues = target.watchValues + ("audio" to audioSpectrumSummary), lastSeenMs = System.currentTimeMillis()))
        }
    }

    fun exportLogsToFile(): File? {
        return runCatching {
            val lines = logs.value
            val outputDir = File(appContext.getExternalFilesDir(null), "exports").apply { mkdirs() }
            val file = File(outputDir, "ghost_tap_logs_${System.currentTimeMillis()}.txt")
            val text = buildString {
                lines.reversed().forEach { l ->
                    append("${l.timestampMs} [${l.category}] (${l.targetId ?: "-"}) ${l.message}\n")
                }
            }
            file.writeText(text)
            log("LOG", null, "Exported logs to ${file.absolutePath}")
            file
        }.getOrNull()
    }

    fun clearLogs() {
        viewModelScope.launch {
            db.logDao().clearAll()
        }
    }

    private fun upsertTarget(target: ScanTarget) {
        targets[target.id] = target
        uiTick++
    }

    private fun hasPermission(permission: String): Boolean {
        return ActivityCompat.checkSelfPermission(appContext, permission) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    private fun log(category: String, targetId: String?, message: String) {
        viewModelScope.launch {
            db.logDao().insert(
                LogEntry(
                    timestampMs = System.currentTimeMillis(),
                    targetId = targetId,
                    category = category,
                    message = message
                )
            )
        }
    }

    override fun onCleared() {
        stopScan()
        gattMap.values.forEach { gatt ->
            runCatching { gatt.disconnect() }
            runCatching { gatt.close() }
        }
        gattMap.clear()
        super.onCleared()
    }
}
